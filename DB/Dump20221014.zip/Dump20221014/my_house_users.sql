-- MySQL dump 10.13  Distrib 8.0.29, for Win64 (x86_64)
--
-- Host: localhost    Database: my_house
-- ------------------------------------------------------
-- Server version	8.0.29

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `USER_SEQ` int NOT NULL AUTO_INCREMENT,
  `USER_NAME` varchar(100) NOT NULL,
  `USER_PASSWORD` varchar(50) NOT NULL,
  `USER_EMAIL` varchar(100) NOT NULL,
  `USER_PROFILE_IMAGE_URL` varchar(500) DEFAULT NULL,
  `USER_REGISTER_DATE` date DEFAULT NULL,
  `user_clsf` varchar(3) DEFAULT NULL,
  PRIMARY KEY (`USER_SEQ`),
  UNIQUE KEY `USER_EMAIL_UNIQUE` (`USER_EMAIL`)
) ENGINE=InnoDB AUTO_INCREMENT=40 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'홍길동','a12345678!','asdf@naver.com','','2022-09-23','001'),(4,'dskim2','1234','dskim2@my.com','/img/lee1.jpg','2021-04-01','001'),(6,'dskim3','1234','dskim3@my.com','','2021-04-01','001'),(11,'aaaa','','',NULL,'2021-04-05','001'),(13,'dskimmm','!Q@W#E$R5t','dskim222@com.com','','2021-04-05','001'),(14,'dskim333','!Q@W#E$R5t','dskim22222@com.com','','2021-04-05','001'),(15,'dskim3333','!Q@W#E$R5t','dskim2223333@com.com','','2021-04-05','001'),(16,'dskim3333','!Q@W#E$R5t','dskim222333333@com.com','','2021-04-05','001'),(17,'eee3','#Ssafy100','111@11.co','','2021-10-10','001'),(18,'3334','#Ssafy100','33@333.com','','2021-10-10','001'),(19,'22222','#Ssafy111','kim@kim.com','','2021-10-10','001'),(20,'ssafy','#Ssafy100','ssafy@ssafy.com','','2021-10-13','001'),(21,'사용자3','!Q@W#E$R5t','user@mail.com','','2021-11-01','001'),(22,'사용자10','!Q@W#E$R5t','ten@ten.com','','2021-11-01','001'),(23,'사용자8','!Q@W#E$R5t','eight@e.com','','2021-11-01','001'),(24,'홍길동','1234','hong@gildong.com',NULL,'2022-03-23','001'),(25,'qqqqq','!Q@W#E$R5t','hong@hong.com','','2022-03-24','001'),(26,'7777','!Q@W#E$R5t','aaa@aaa.com','','2022-04-14','001'),(27,'8888','!Q@W#E$R5t','bbb@bb.com','','2022-04-14','001'),(28,'dskim99','!Q@W#E$R5t','99@mail.com','','2022-04-28','001'),(29,'dskim100','!Q@W#E$R5t','1969dskim22@naver.com','','2022-04-28','001'),(30,'dskim98','!Q@W#E$R5t','89@mail.com','','2022-04-28','001'),(31,'ssafy','a12345678!','ssafy2@ssafy.com','','2022-09-23','001'),(37,'ssafy','a12345678!','ssafy3@ssafy.com','','2022-09-28','002'),(39,'suna','suna123!','suna@ssafy.com','','2022-10-12','003');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-10-14  8:35:10
